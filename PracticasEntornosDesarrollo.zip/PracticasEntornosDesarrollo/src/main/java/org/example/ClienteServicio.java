package org.example;

public class ClienteServicio {

    public boolean esIdClienteValido(String id) {
        return id != null && id.matches("\\d{4}");
    }

    public boolean esNombreValido(String nombre) {
        return nombre != null && !nombre.trim().isEmpty();
    }

    public boolean esApellidoValido(String apellido) {
        return apellido != null && !apellido.trim().isEmpty();
    }

    public boolean esTelefonoValido(String telefono) {
        return telefono != null && telefono.matches("\\d{9}");
    }

    public String validarCliente(String id, String nombre, String apellido, String telefono) {
        if (!esIdClienteValido(id)) return "Error -1: ID inválido";
        if (!esNombreValido(nombre)) return "Error -2: Nombre inválido";
        if (!esApellidoValido(apellido)) return "Error -3: Apellido inválido";
        if (!esTelefonoValido(telefono)) return "Error -4: Teléfono inválido";
        return "Cliente válido";
    }
}
