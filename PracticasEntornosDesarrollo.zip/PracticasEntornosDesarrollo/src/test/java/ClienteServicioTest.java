import org.example.ClienteServicio;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ClienteServicioTest {

    ClienteServicio service = new ClienteServicio();

    // Pruebas de caja negra
    @Test
    public void testIdClienteValido() {
        assertTrue(service.esIdClienteValido("1234"));
        assertFalse(service.esIdClienteValido("12"));
        assertFalse(service.esIdClienteValido("abcd"));
        assertFalse(service.esIdClienteValido(""));
        assertFalse(service.esIdClienteValido(null));
    }

    @Test
    public void testNombreValido() {
        assertTrue(service.esNombreValido("Juan"));
        assertFalse(service.esNombreValido(""));
        assertFalse(service.esNombreValido(null));
        assertFalse(service.esNombreValido("   "));
    }

    @Test
    public void testApellidoValido() {
        assertTrue(service.esApellidoValido("García"));
        assertFalse(service.esApellidoValido(""));
        assertFalse(service.esApellidoValido(null));
        assertFalse(service.esApellidoValido("   "));
    }

    @Test
    public void testTelefonoValido() {
        assertTrue(service.esTelefonoValido("600123456"));
        assertFalse(service.esTelefonoValido("12345"));
        assertFalse(service.esTelefonoValido("abcdefghi"));
        assertFalse(service.esTelefonoValido(""));
        assertFalse(service.esTelefonoValido(null));
    }

    // Pruebas de caja blanca (caminos lógicos)
    @Test
    public void testTodosLosCaminos() {
        // id correcto y incorrecto
        assertTrue(service.esIdClienteValido("9999"));
        assertFalse(service.esIdClienteValido("abcd"));

        // nombre y apellido vacíos
        assertFalse(service.esNombreValido(""));
        assertFalse(service.esApellidoValido(""));

        // teléfono con letras
        assertFalse(service.esTelefonoValido("12345abc9"));
    }

    //  validar cliente completo con mensajes de error
    @Test
    public void testValidarCliente() {
        // Todos los datos válidos
        assertEquals("Cliente válido", service.validarCliente("1234", "Juan", "Pérez", "600123456"));

        // ID inválido
        assertEquals("Error -1: ID inválido", service.validarCliente("12", "Juan", "Pérez", "600123456"));

        // Nombre inválido
        assertEquals("Error -2: Nombre inválido", service.validarCliente("1234", "", "Pérez", "600123456"));

        // Apellido inválido
        assertEquals("Error -3: Apellido inválido", service.validarCliente("1234", "Juan", "", "600123456"));

        // Teléfono inválido
        assertEquals("Error -4: Teléfono inválido", service.validarCliente("1234", "Juan", "Pérez", "123"));
    }
}
